# z-ark Digivice: common-red-two-devices

Current enclosure revision: C14-P19. Variant: both.
This plate contains 4 printed parts for 2 devices.

This common plate is reused unchanged from C13 and is current for C14-P19. Legacy C13 names inside the native project are intentional.
The white RF window is a separate part; choose a full-white plate if new windows are needed.

Prepared for Anycubic Kobra S1, PLA, 0.4 mm nozzle. These printer-specific
toolpaths are not universal. Confirm that this machine and material profile
match your setup before using G-code. No printing is triggered by this package.
Slicer estimate: 42m43s, 15.89 g; not a physical print measurement.

Contents: unchanged native 3MF project and its byte-identical embedded/external
G-code pair, plus SHA256SUMS.txt. Verify from the extracted directory with:

    shasum -a 256 -c SHA256SUMS.txt

The full-white choices include two fronts and two unchanged small RF windows.
Front-pair repair choices contain only two fronts and reuse existing windows.
Black and red parts, small white windows, screw locations and lengths are
unchanged. Black pilots stay 1.6 mm; through-clearances stay 2.4 mm.

Assembly: use the C14-P19 Assembly and Screws guide in the repository's
hardware/c14-p19/docs directory. First build without NFC uses 17 screws:
4 x M2 x 16, 3 x M2 x 4, 10 x M2 x 8. The optional NFC tray adds 3 x M2 x 8.
Double screw counts for two devices. Panel-switch mounting hardware is separate.

Physical fit, screw grip and battery compatibility remain unverified. White
pilots are smooth, not modeled threads; enlargement can reduce screw hold.
Do not test a full 16 mm screw in the bare white shell: the assembled stack
limits its nominal white-shell penetration to 6.4 mm.

Frozen source handoff SHA-256: 9ec2a48799fce0367a36172e83243ad0f088be0c24bd98b26d7c4f4bc654d296
Payload hashes are preserved; this packaging step does not rebuild or reslice.
No project-wide redistribution license has been selected.
